# Sigma-Spy-Reuploaded
This is a reuploaded version of Depthso's Sigma Spy.

If depthso is reading this, i hope your doing well, and if you want me to take this down, i will.

# Usage:

```
loadstring(
    game:HttpGet(
        'https://raw.githubusercontent.com/boowoompTheOffical/Sigma-Spy-Reuploaded/refs/heads/main/Main.lua'
    ),
    'Sigma Spy'
)()

```
