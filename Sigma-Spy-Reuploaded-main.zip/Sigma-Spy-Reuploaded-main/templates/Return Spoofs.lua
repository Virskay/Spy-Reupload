--// Sigma Spy custom remote responces
--// The Return table will be unpacked for the responce

return {
	-- [game.ReplicatedStorage.Remotes.HelloWorld] = {
	-- 	Method = "FireServer",
	-- 	Return = {"Hello world from Sigma Spy!"}
	-- }
}